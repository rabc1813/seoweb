<!doctype html>
<html lang="en">

<!-- Mirrored from demo.stairthemes.com/html/traveler/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 07 Dec 2023 07:01:46 GMT -->

<head>
   <!-- Required meta tags -->
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

   <!-- favicon -->
   <link rel="icon" type="image/png" href="assets/images/favicon.png">
   <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="assets/vendors/bootstrap/css/bootstrap.min.css" media="all">
   <!-- jquery-ui css -->
   <link rel="stylesheet" type="text/css" href="assets/vendors/jquery-ui/jquery-ui.min.css">
   <!-- fancybox box css -->
   <link rel="stylesheet" type="text/css" href="assets/vendors/fancybox/dist/jquery.fancybox.min.css">
   <!-- Fonts Awesome CSS -->
   <link rel="stylesheet" type="text/css" href="assets/vendors/fontawesome/css/all.min.css">
   <!-- Elmentkit Icon CSS -->
   <link rel="stylesheet" type="text/css" href="assets/vendors/elementskit-icon-pack/assets/css/ekiticons.css">
   <!-- slick slider css -->
   <link rel="stylesheet" type="text/css" href="assets/vendors/slick/slick.css">
   <link rel="stylesheet" type="text/css" href="assets/vendors/slick/slick-theme.css">
   <!-- google fonts -->
   <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400&amp;family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400&amp;display=swap"
      rel="stylesheet">
   <!-- Custom CSS -->
   <link rel="stylesheet" type="text/css" href="style.css">
   <title>Contact | Rhino Travels: Your Premier Taxi Rental and Tours Partner in Guwahati, Assam</title>
</head>

<body>
   <div id="siteLoader" class="site-loader">
      <div class="preloader-content">
         <img src="assets/images/loader1.gif" alt="">
      </div>
   </div>
   <div id="page" class="page">
      <!-- ***site header html start*** -->
      <?php include 'header.php';?>
      <!-- ***site header html end*** -->
      <main id="content" class="site-main">
         <section class="contact-inner-page">
            <!-- ***Inner Banner html start form here*** -->
            <div class="inner-banner-wrap">
               <div class="inner-baner-container" style="background-image: url(assets/images/Guwahati-b1.jpg);">
                  <div class="container">
                     <div class="inner-banner-content">
                        <h1 class="page-title">Contact US</h1>
                     </div>
                  </div>
               </div>
            </div>
            <!-- ***Inner Banner html end here*** -->
            <!-- ***contact section html start form here*** -->
            <div class="inner-contact-wrap">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-6">
                        <div class="section-heading">
                           <h5 class="sub-title">GET IN TOUCH</h5>
                           <h2 class="section-title">REACH & CONTACT US!</h2>
                           <p>Ready to explore Assam with Rhino Travels? Reach out to us today to book your taxi, customize a tour package, or inquire about our services. Let us be your travel partner in discovering the beauty and charm of Guwahati and beyond.</p>
                           <div class="social-icon">
                              <ul>
                                 <li>
                                    <a href="" target="_blank">
                                       <i class="fab fa-facebook-f" aria-hidden="true"></i>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="" target="_blank">
                                       <i class="fab fa-twitter" aria-hidden="true"></i>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="" target="_blank">
                                       <i class="fab fa-youtube" aria-hidden="true"></i>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="" target="_blank">
                                       <i class="fab fa-instagram" aria-hidden="true"></i>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="" target="_blank">
                                       <i class="fab fa-pinterest" aria-hidden="true"></i>
                                    </a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                        <div class="contact-map">
                           <iframe
                              src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3582.281818780477!2d91.79343167541246!3d26.122352677127104!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMjbCsDA3JzIwLjUiTiA5McKwNDcnNDUuNiJF!5e0!3m2!1sen!2sin!4v1701935181344!5m2!1sen!2sin"
                              width="600" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                     </div>
                     <div class="col-lg-6">
                        <div class="contact-from-wrap primary-bg">
                           <form method="get" class="contact-from">
                              <p>
                                 <label>First Name..</label>
                                 <input type="text" name="name" placeholder="Your Name*">
                              </p>
                              <p>
                                 <label>Email Address</label>
                                 <input type="email" name="email" placeholder="Your Email*">
                              </p>
                              <p>
                                 <label>Comments / Questions</label>
                                 <textarea rows="8" placeholder="Your Message*"></textarea>
                              </p>
                              <p>
                                 <input type="submit" name="submit" value="SUBMIT MESSAGE">
                              </p>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- ***contact section html start form here*** -->
            <!-- ***iconbox section html start form here*** -->
            <div class="contact-details-section bg-light-grey">
               <div class="container">
                  <div class="row align-items-center">
                     <div class="col-lg-4">
                        <div class="icon-box border-icon-box">
                           <div class="box-icon">
                              <i aria-hidden="true" class="fas fa-envelope-open-text"></i>
                           </div>
                           <div class="icon-box-content">
                              <h4>EMAIL ADDRESS</h4>
                              <ul>
                                 <li>
                                    <a href="mailto:adtourstravels19@gmail.com">adtourstravels19@gmail.com</a>
                                 </li>
                                
                              </ul>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4">
                        <div class="icon-box border-icon-box">
                           <div class="box-icon">
                              <i aria-hidden="true" class="fas fa-phone-alt"></i>
                           </div>
                           <div class="icon-box-content">
                              <h4>PHONE NUMBER</h4>
                              <ul>
                                 <li>
                                    <a href="tel:+91 9577480547">+91 9577480547</a>
                                 </li>
                                 <li>
                                    <a href="tel:+91 7002344388">+91 7002344388</a>
                                 </li>
                                 
                              </ul>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4">
                        <div class="icon-box border-icon-box">
                           <div class="box-icon">
                              <i aria-hidden="true" class="fas fa-map-marker-alt"></i>
                           </div>
                           <div class="icon-box-content">
                              <h4>ADDRESS LOCATION</h4>
                              <ul>
                                 <li>
                                 House No. 216, Bishnu Rabha Path, Beltola Tiniali, Guwahati, Assam 781028
                                 </li>
                                
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- ***iconbox section html end here*** -->
         </section>
      </main>
      <!-- ***site footer html start form here*** -->
      <?php include 'footer.php';?>
      <!-- ***site footer html end*** -->
      <a id="backTotop" href="#" class="to-top-icon">
         <i class="fas fa-chevron-up"></i>
      </a>
      <!-- ***custom search field html*** -->
 
      <!-- ***custom top bar offcanvas html*** -->
   </div>

   <!-- JavaScript -->
   <script src="assets/vendors/jquery/jquery.js"></script>
   <script src="assets/vendors/waypoint/waypoints.js"></script>
   <script src="assets/vendors/bootstrap/js/bootstrap.min.js"></script>
   <script src="assets/vendors/jquery-ui/jquery-ui.min.js"></script>
   <script src="assets/vendors/countdown-date-loop-counter/loopcounter.js"></script>
   <script src="assets/vendors/counterup/jquery.counterup.min.js"></script>
   <script src="../../../unpkg.com/imagesloaded%404.1.4/imagesloaded.pkgd.min.js"></script>
   <script src="assets/vendors/masonry/masonry.pkgd.min.js"></script>
   <script src="assets/vendors/slick/slick.min.js"></script>
   <script src="assets/vendors/fancybox/dist/jquery.fancybox.min.js"></script>
   <script src="assets/vendors/slick-nav/jquery.slicknav.js"></script>
   <script src="assets/js/custom.min.js"></script>
</body>

<!-- Mirrored from demo.stairthemes.com/html/traveler/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 07 Dec 2023 07:01:46 GMT -->

</html>