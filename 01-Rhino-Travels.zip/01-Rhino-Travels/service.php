<!doctype html>
<html lang="en">

<!-- Mirrored from demo.stairthemes.com/html/traveler/service.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 07 Dec 2023 07:00:51 GMT -->

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- favicon -->
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendors/bootstrap/css/bootstrap.min.css" media="all">
    <!-- jquery-ui css -->
    <link rel="stylesheet" type="text/css" href="assets/vendors/jquery-ui/jquery-ui.min.css">
    <!-- fancybox box css -->
    <link rel="stylesheet" type="text/css" href="assets/vendors/fancybox/dist/jquery.fancybox.min.css">
    <!-- Fonts Awesome CSS -->
    <link rel="stylesheet" type="text/css" href="assets/vendors/fontawesome/css/all.min.css">
    <!-- Elmentkit Icon CSS -->
    <link rel="stylesheet" type="text/css" href="assets/vendors/elementskit-icon-pack/assets/css/ekiticons.css">
    <!-- slick slider css -->
    <link rel="stylesheet" type="text/css" href="assets/vendors/slick/slick.css">
    <link rel="stylesheet" type="text/css" href="assets/vendors/slick/slick-theme.css">
    <!-- google fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400&amp;family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400&amp;display=swap"
        rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Service | Rhino Travels: Your Premier Taxi Rental and Tours Partner in Guwahati, Assam</title>
</head>

<body>
    <div id="siteLoader" class="site-loader">
        <div class="preloader-content">
            <img src="assets/images/loader1.gif" alt="">
        </div>
    </div>
    <div id="page" class="page">
        <!-- ***site header html start*** -->
        <?php include 'header.php';?>
        <!-- ***site header html end*** -->
        <main id="content" class="site-main">
            <section class="service-inner-page inner-page-wrap">
                <!-- ***Inner Banner html start form here*** -->
                <div class="inner-banner-wrap">
                    <div class="inner-baner-container" style="background-image: url(assets/images/Guwahati-b1.jpg);">
                        <div class="container">
                            <div class="inner-banner-content">
                                <h1 class="page-title">Services</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ***Inner Banner html end here*** -->
                <!-- ***about section html start form here*** -->

                <!-- ***about section html start form here*** -->
                <!-- ***callback section html start form here*** -->
                <section class="home-destination">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-8 offset-lg-2 text-sm-center">
                                <div class="section-heading">
                                    <!-- <h5 class="sub-title">Our </h5> -->
                                    <h2 class="section-title">Service</h2>
                                    <p>At Rhino Travels, our story is woven with the vibrant threads of Assam's rich
                                        culture, diverse landscapes, and the warm hospitality that defines the
                                        Northeastern spiri</p>
                                </div>
                            </div>
                        </div>
                        <div class="destination-section">
                            <div class="row">
                                <div class="col-lg-4 col-md-6">
                                    <article class="destination-item"
                                        style="background-image: url(assets/images/Professional-Drivers.jpg);min-height: 276px;">

                                    </article>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <article class="destination-item"
                                        style="background-image: url(assets/images/Affordable-Rates.jpg);min-height: 188px;">

                                    </article>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <article class="destination-item"
                                        style="background-image: url(assets/images/24-7-Availability.jpg);min-height: 276px;">

                                    </article>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>
                <!-- ***callback section html end here*** -->
            </section>


            <div class="inner-service-wrap">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-4 col-sm-6">
                            <div class="icon-box bg-img-box" style="background-image: url(assets/images/img13.jpg);">
                                <div class="box-icon">
                                    <i class="fas fa-file-alt"></i>
                                </div>
                                <div class="icon-box-content">
                                    <h3>Fleet of Comfort</h3>
                                    <p>Our well-maintained fleet of vehicles ensures a comfortable and secure journey for every passenger. From compact cars for city explorations to spacious SUVs for family adventures, we have the perfect ride for every occasion.</p>
                                    <a href="#" class="round-btn">Learn More</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="icon-box bg-img-box" style="background-image: url(assets/images/bg-d.jpg);">
                                <div class="box-icon">
                                    <i class="fas fa-bus"></i>
                                </div>
                                <div class="icon-box-content">
                                    <h3>Professional Drivers</h3>
                                    <p>Behind the wheel, our experienced and courteous drivers stand ready to make your journey memorable. Punctuality, safety, and a friendly demeanor are the hallmarks of our dedicated chauffeurs</p>
                                    <a href="#" class="round-btn">Learn More</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="icon-box bg-img-box" style="background-image: url(assets/images/img10.jpg);">
                                <div class="box-icon">
                                    <i class="fas fa-headset"></i>
                                </div>
                                <div class="icon-box-content">
                                    <h3>Customer-Centric Approach</h3>
                                    <p> Your satisfaction is our priority. We pride ourselves on offering personalized services, transparent pricing, and flexibility to meet the unique needs of each traveler.</p>
                                    <a href="#" class="round-btn">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <!-- cars  -->
            <div class="destination-item-wrap">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 text-sm-center">
                <div class="section-heading">
                    <h5 class="sub-title">Our Cars</h5>
                    <h2 class="section-title">Best Cars In Assam</h2>
                </div>
            </div>
        </div>
        <div class="row gx-5">
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-1-Swift-dzire.jpg); min-height: 270px;">
                    <div class="destination-content">

                        <h3>
                            <a href="contact.php">Swift dzire</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-2-Aura.jpg); min-height: 270px;">
                    <div class="destination-content">
                        
                        <h3>
                            <a href="contact.php">Aura</a>
                        </h3>

                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-3-Xcent.jpg); min-height: 270px;">
                    <div class="destination-content">

                        <h3>
                            <a href="contact.php">Xcent</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-4-Ertiga.jpg); min-height: 270px;">
                    <div class="destination-content">
                        
                        <h3>
                            <a href="contact.php">Ertiga</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-5-Innova.png); min-height: 270px;">
                    <div class="destination-content">
                        
                        <h3>
                            <a href="contact.php">Innova</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-6-Innova-crsta.jpeg); min-height: 270px;">
                    <div class="destination-content">
                        <h3>
                            <a href="contact.php">innova crysta</a>
                        </h3>
                    </div>
                </article>
            </div>
        </div>
    </div>
</div>
            <!-- cars  -->


        </main>
        <!-- ***site footer html start form here*** -->
        <?php include 'footer.php';?>
        <!-- ***site footer html end*** -->
        <a id="backTotop" href="#" class="to-top-icon">
            <i class="fas fa-chevron-up"></i>
        </a>


    </div>

    <!-- JavaScript -->
    <script src="assets/vendors/jquery/jquery.js"></script>
    <script src="assets/vendors/waypoint/waypoints.js"></script>
    <script src="assets/vendors/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/vendors/jquery-ui/jquery-ui.min.js"></script>
    <script src="assets/vendors/countdown-date-loop-counter/loopcounter.js"></script>
    <script src="assets/vendors/counterup/jquery.counterup.min.js"></script>
    <script src="../../../unpkg.com/imagesloaded%404.1.4/imagesloaded.pkgd.min.js"></script>
    <script src="assets/vendors/masonry/masonry.pkgd.min.js"></script>
    <script src="assets/vendors/slick/slick.min.js"></script>
    <script src="assets/vendors/fancybox/dist/jquery.fancybox.min.js"></script>
    <script src="assets/vendors/slick-nav/jquery.slicknav.js"></script>
    <script src="assets/js/custom.min.js"></script>
</body>

<!-- Mirrored from demo.stairthemes.com/html/traveler/service.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 07 Dec 2023 07:00:51 GMT -->

</html>