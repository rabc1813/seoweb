<footer id="colophon" class="site-footer footer-primary">
         <div class="top-footer">
            <div class="container">
               <div class="upper-footer">
                  <div class="row">
                     <div class="col-lg-3 col-sm-6">
                        <aside class="widget widget_text">
                           <div class="footer-logo">
                              <a href="index.html"><img src="assets/images/logo.png" alt=""></a>
                           </div>
                           <div class="textwidget widget-text">
                           Welcome to Rhino Travels, your trusted companion for seamless travel experiences in the enchanting landscapes of Guwahati, Assam.
                           </div>
                        </aside>
                     </div>
                     <div class="col-lg-3 col-sm-6">
                        <aside class="widget widget_text">
                           <h3 class="widget-title">UseFullLinks</h3>
                           <div class="textwidget widget-text">
                              <ul>
                                 <li>
                                    <a href="index.php">Home</a>
                                 </li>
                                 <li>
                                    <a href="about.php">About</a>
                                 </li>
                                 <li>
                                    <a href="service.php">Service</a>
                                 </li>
                                 <li>
                                    <a href="gallery.php">Gallery</a>
                                 </li>
                                 <li>
                                    <a href="contact.php">Contact Us</a>
                                 </li>
                                 
                                 


                              </ul>
                           </div>
                        </aside>
                     </div>
                     <div class="col-lg-3 col-sm-6">
                        <aside class="widget widget_text">
                           <h3 class="widget-title">CONTACT US</h3>
                           <div class="textwidget widget-text">
                              <p>Feel free to contact and<br /> reach us !!</p>
                              <ul>
                                 <li>
                                    <a href="tel:+91 9577480547">
                                       <i aria-hidden="true" class="icon icon-phone1"></i>
                                       +91 9577480547
                                    </a>
                                 </li>
                                 <li>
                                    <a href="tel:+91 7002344388">
                                       <i aria-hidden="true" class="icon icon-phone1"></i>
                                       +91 7002344388
                                    </a>
                                 </li>
                                 <li>
                                    <a href="mailto:adtourstravels19@gmail.com">
                                       <i aria-hidden="true" class="icon icon-envelope1"></i>
                                       adtourstravels19@gmail.com
                                    </a>
                                 </li>
                                 <li>
                                    <i aria-hidden="true" class="icon icon-map-marker1"></i>
                                    House No. 216, Bishnu Rabha Path, Beltola Tiniali, Guwahati, Assam 781028
                                 </li>
                              </ul>
                           </div>
                        </aside>
                     </div>
                     <div class="col-lg-3 col-sm-6">
                        <aside class="widget">
                           <h3 class="widget-title">Google Map</h3>
                           <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3582.281818780477!2d91.79343167541246!3d26.122352677127104!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMjbCsDA3JzIwLjUiTiA5McKwNDcnNDUuNiJF!5e0!3m2!1sen!2sin!4v1701935181344!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </aside>
                     </div>
                  </div>
               </div>
               <div class="lower-footer">
                  <div class="row align-items-center">
                     <div class="col-lg-6">
                        <div class="footer-newsletter">
                           <p>Subscribe our newsletter for more update & news !!</p>
                           <form class="newsletter">
                              <input type="email" name="email" placeholder="Enter Your Email">
                              <button type="submit" class="outline-btn outline-btn-white">Subscribe</button>
                           </form>
                        </div>
                     </div>
                     <div class="col-lg-6 text-right">
                        <div class="social-icon">
                           <ul>
                              <li>
                                 <a href="" target="_blank">
                                    <i class="fab fa-facebook-f" aria-hidden="true"></i>
                                 </a>
                              </li>
                              <li>
                                 <a href="" target="_blank">
                                    <i class="fab fa-twitter" aria-hidden="true"></i>
                                 </a>
                              </li>
                              <li>
                                 <a href="" target="_blank">
                                    <i class="fab fa-youtube" aria-hidden="true"></i>
                                 </a>
                              </li>
                              <li>
                                 <a href="" target="_blank">
                                    <i class="fab fa-instagram" aria-hidden="true"></i>
                                 </a>
                              </li>
                              <li>
                                 <a href="" target="_blank">
                                    <i class="fab fa-linkedin" aria-hidden="true"></i>
                                 </a>
                              </li>
                           </ul>
                        </div>
                        
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="bottom-footer">
            <div class="container">
               <div class="copy-right text-center">Copyright &copy; 2023 Rabdigitalgrowth.com. All rights reserved.</div>
            </div>
         </div>
      </footer>