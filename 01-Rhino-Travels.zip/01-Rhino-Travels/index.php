<!doctype html>
<html lang="en">

<!-- Mirrored from demo.stairthemes.com/html/traveler/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 07 Dec 2023 06:57:57 GMT -->

<head>
   <!-- Required meta tags -->
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

   <!-- favicon -->
   <link rel="icon" type="image/png" href="assets/images/favicon.png">
   <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="assets/vendors/bootstrap/css/bootstrap.min.css" media="all">
   <!-- jquery-ui css -->
   <link rel="stylesheet" type="text/css" href="assets/vendors/jquery-ui/jquery-ui.min.css">
   <!-- fancybox box css -->
   <link rel="stylesheet" type="text/css" href="assets/vendors/fancybox/dist/jquery.fancybox.min.css">
   <!-- Fonts Awesome CSS -->
   <link rel="stylesheet" type="text/css" href="assets/vendors/fontawesome/css/all.min.css">
   <!-- Elmentkit Icon CSS -->
   <link rel="stylesheet" type="text/css" href="assets/vendors/elementskit-icon-pack/assets/css/ekiticons.css">
   <!-- slick slider css -->
   <link rel="stylesheet" type="text/css" href="assets/vendors/slick/slick.css">
   <link rel="stylesheet" type="text/css" href="assets/vendors/slick/slick-theme.css">
   <!-- google fonts -->
   <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400&amp;family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400&amp;display=swap"
      rel="stylesheet">
   <!-- Custom CSS -->
   <link rel="stylesheet" type="text/css" href="style.css">
   <title>Rhino Travels: Your Premier Taxi Rental and Tours Partner in Guwahati, Assam</title>
</head>

<body class="home">
   <div id="siteLoader" class="site-loader">
      <div class="preloader-content">
         <img src="assets/images/loader1.gif" alt="">
      </div>
   </div>
   <div id="page" class="page">
      <!-- site header html start  -->
      <?php include 'header.php';?>
      <!-- site header html end  -->
      <main id="content" class="site-main">
         <!-- ***home banner html start form here*** -->
         <section class="home-banner-section home-banner-slider">
            <div class="home-banner d-flex flex-wrap align-items-center"
               style="background-image: url(assets/images/assam-b2.jpg);">
               <div class="overlay"></div>
               <div class="container">
                  <div class="banner-content text-center">
                     <div class="row">
                        <div class="col-lg-8 offset-lg-2">
                           <h2 class="banner-title">Welcome to Rhino Travels</h2>
                           <p>Discover Assam's Beauty with Rhino Travels – Your Premier Taxi Rental and Tours Provider in Guwahati</p>
                           <div class="banner-btn">
                              <a href="about.php" class="round-btn">About</a>
                              <a href="contact.php" class="outline-btn outline-btn-white">BOOK Now</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="home-banner d-flex flex-wrap align-items-center"
               style="background-image: url(assets/images/Guwahati-b1.jpg);">
               <div class="overlay"></div>
               <div class="container">
                  <div class="banner-content text-center">
                     <div class="row">
                        <div class="col-lg-8 offset-lg-2">
                           <h2 class="banner-title">Experience Comfort and Convenience</h2>
                           <p>Our fleet of well-maintained vehicles ensures a smooth and secure journey for every traveler.</p>
                           <div class="banner-btn">
                              <a href="about.php" class="round-btn">About</a>
                              <a href="contact.php" class="outline-btn outline-btn-white">BOOK NOW</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- ***home banner html end here*** -->

         <!-- ***Home destination html start from here*** -->
         <section class="home-destination">
            <div class="container">
               <div class="row">
                  <div class="col-lg-8 offset-lg-2 text-sm-center">
                     <div class="section-heading">
                        <h5 class="sub-title">Our </h5>
                        <h2 class="section-title">Service</h2>
                        <p>At Rhino Travels, our story is woven with the vibrant threads of Assam's rich culture, diverse landscapes, and the warm hospitality that defines the Northeastern spiri</p>
                     </div>
                  </div>
               </div>
               <div class="destination-section">
                  <div class="row">
                     <div class="col-lg-4 col-md-6">
                        <article class="destination-item" style="background-image: url(assets/images/Professional-Drivers.jpg);min-height: 276px;">
                           
                        </article>
                     </div>
                     <div class="col-lg-4 col-md-6">
                        <article class="destination-item" style="background-image: url(assets/images/Affordable-Rates.jpg);min-height: 188px;">
                           
                        </article>
                     </div>
                     <div class="col-lg-4 col-md-6">
                        <article class="destination-item" style="background-image: url(assets/images/24-7-Availability.jpg);min-height: 276px;">
                          
                        </article>
                     </div>
                  </div>

               </div>
            </div>
         </section>
         <!-- ***Home destination html end here*** -->
        
         <!-- cars  -->
<!-- cars  -->
<div class="destination-item-wrap">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 text-sm-center">
                <div class="section-heading">
                    <h5 class="sub-title">Our Cars</h5>
                    <h2 class="section-title">Best Cars In Assam</h2>
                </div>
            </div>
        </div>
        <div class="row gx-5">
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-1-Swift-dzire.jpg); min-height: 270px;">
                    <div class="destination-content">

                        <h3>
                            <a href="contact.php">Swift dzire</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-2-Aura.jpg); min-height: 270px;">
                    <div class="destination-content">
                        
                        <h3>
                            <a href="contact.php">Aura</a>
                        </h3>

                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-3-Xcent.jpg); min-height: 270px;">
                    <div class="destination-content">

                        <h3>
                            <a href="contact.php">Xcent</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-4-Ertiga.jpg); min-height: 270px;">
                    <div class="destination-content">
                        
                        <h3>
                            <a href="contact.php">Ertiga</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-5-Innova.png); min-height: 270px;">
                    <div class="destination-content">
                        
                        <h3>
                            <a href="contact.php">Innova</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item" style="background-image: url(assets/images/cars/car-6-Innova-crsta.jpeg); min-height: 270px;">
                    <div class="destination-content">
                        <h3>
                            <a href="contact.php">innova crysta</a>
                        </h3>
                    </div>
                </article>
            </div>
        </div>
    </div>
</div>
<!-- cars  -->
         <!-- cars  -->

         <!-- ***Home callback html start from here*** -->
         <section class="home-callback bg-img-fullcallback" style="background-image: url(assets/images/bg.jpg);">
            <div class="overlay"></div>
            <div class="container">
               <div class="row">
                  <div class="col-lg-8 offset-lg-2 text-center">
                     <div class="callback-content">
                        <div class="video-button">
                           <!-- <a id="video-container" data-fancybox="video-gallery"
                              href="https://www.youtube.com/watch?v=2OYar8OHEOU">
                              <i class="fas fa-play"></i>
                           </a> -->
                        </div>
                        <h2 class="section-title">Ready to explore Assam with Rhino Travels? </h2>
                        <p>Ready to explore Assam with Rhino Travels? Reach out to us today to book your taxi, customize a tour package, or inquire about our services.</p>
                        <div class="callback-btn">
                           <a href="service.php" class="round-btn">Service</a>
                           <a href="about.php" class="outline-btn outline-btn-white">About</a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- ***Home callback html end here*** -->
         <!-- ***Home counter html start from here*** -->
         <div class="home-counter">
            <div class="container">
               <div class="counter-wrap">
                  <div class="counter-item">
                     <span class="counter-no">
                        <span class="counter">80</span>K+
                     </span>
                     <span class="counter-desc">
                        SATISFIED CUSTOMER
                     </span>
                  </div>
                  <div class="counter-item">
                     <span class="counter-no">
                        <span class="counter">18</span>+
                     </span>
                     <span class="counter-desc">
                        ACTIVE MEMBERS
                     </span>
                  </div>
                  <div class="counter-item">
                     <span class="counter-no">
                        <span class="counter">220</span>+
                     </span>
                     <span class="counter-desc">
                        TOUR DESTINATION
                     </span>
                  </div>
                  <div class="counter-item">
                     <span class="counter-no">
                        <span class="counter">75</span>+
                     </span>
                     <span class="counter-desc">
                        TRAVEL GUIDES
                     </span>
                  </div>
               </div>
            </div>
         </div>
         <!-- ***Home counter html end here*** -->
         <!-- ***Home offer html start from here*** -->
         <!-- tours  -->
         <div class="destination-item-wrap">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 text-sm-center">
                <div class="section-heading">
                    <h5 class="sub-title">Places</h5>
                    <h2 class="section-title">Guwahati Tourism</h2>
                </div>
            </div>
        </div>
        <div class="row gx-5">
            <div class="col-lg-4 col-md-6">
                <article class="destination-item"
                    style="background-image: url(assets/images/1-Umananda-Temple.png); min-height: 270px;">
                    <div class="destination-content">

                        <h3>
                            <a href="contact.php">Umananda Temple</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item"
                    style="background-image: url(assets/images/2-Kamakhya-Temple.jpg); min-height: 270px;">
                    <div class="destination-content">

                        <h3>
                            <a href="contact.php">Kamakhya Temple</a>
                        </h3>

                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item"
                    style="background-image: url(assets/images/3-Guwahati-Zoo.jpg); min-height: 270px;">
                    <div class="destination-content">

                        <h3>
                            <a href="contact.php">Guwahati Zoo</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item"
                    style="background-image: url(assets/images/4-Umananda-Island.jpg); min-height: 270px;">
                    <div class="destination-content">

                        <h3>
                            <a href="contact.php">Umananda Island</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item"
                    style="background-image: url(assets/images/5-Pobitora-Wildlife-Sanctuary.jpg); min-height: 270px;">
                    <div class="destination-content">

                        <h3>
                            <a href="contact.php">Pobitora Wildlife Sanctuary</a>
                        </h3>
                    </div>
                </article>
            </div>
            <div class="col-lg-4 col-md-6">
                <article class="destination-item"
                    style="background-image: url(assets/images/6-Cruising-in-the-Brahmaputra.jpg); min-height: 270px;">
                    <div class="destination-content">
                        <h3>
                            <a href="contact.php">Cruising in the Brahmaputra</a>
                        </h3>
                    </div>
                </article>
            </div>
        </div>
    </div>
</div>    
         <!-- tours  -->
         <!-- ***Home offer html end here*** -->
         <!-- ***Home client html start from here*** -->
         <section class="home-client client-section" style="background-image: url(assets/images/bg-flex.jpg);">
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-lg-6">
                     <div class="client-content">
                        <h5 class="sub-title">Your Happiness is Our Priority</h5>
                        <h2 class="section-title">Customer Satisfaction</h2>
                        <p>We are committed to providing transparent services, competitive pricing, and a customer-centric approach.</p>
                        <a href="contact.php" class="round-btn">Contact Now</a>
                     </div>
                  </div>
                  <div class="col-lg-6">
                     <div class="client-logo">
                        <ul>
                           <li>
                              <img src="assets/images/client-img1.png" alt="">
                           </li>
                           <li>
                              <img src="assets/images/client-img2.png" alt="">
                           </li>
                           <li>
                              <img src="assets/images/client-img3.png" alt="">
                           </li>
                           <li>
                              <img src="assets/images/client-img4.png" alt="">
                           </li>
                           <li>
                              <img src="assets/images/client-img5.png" alt="">
                           </li>
                           <li>
                              <img src="assets/images/client-img6.png" alt="">
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
            <div class="overlay"></div>
         </section>
         <!-- ***Home client html end here*** -->

         <!-- ***Home testimonial html start from here*** -->
         <section class="home-testimonial">
            <div class="container">
               <div class="row">
                  <div class="col-lg-8 offset-lg-2 text-center">
                     <div class="section-heading">
                        <h5 class="sub-title">CLIENT'S REVIEWS</h5>
                        <h2 class="section-title">A Memorable Journey with Rhino Travels</h2>
                     </div>
                  </div>
               </div>
               <div class="testimonial-section testimonial-slider">
                  <div class="testimonial-item">
                     <div class="testimonial-content">
                        <div class="rating-start-wrap">
                           <div class="rating-start">
                              <span style="width: 80%"></span>
                           </div>
                        </div>
                        <p>"Our experience with Rhino Travels was nothing short of exceptional! From the moment we booked our taxi to the end of our guided tour, every detail was handled with utmost professionalism and care. The fleet of vehicles was clean and comfortable, and our driver was not only punctual but also a knowledgeable guide throughout our journey.</p>
                        <div class="author-content">
                           <figure class="testimonial-img">
                              <img src="assets/images/img18.jpg" alt="">
                           </figure>
                           <div class="author-name">
                              <h5>WILLIAM WRIGHT</h5>
                              <span>TRAVELLERS</span>
                           </div>
                        </div>
                        <div class="testimonial-icon">
                           <i aria-hidden="true" class="fas fa-quote-left"></i>
                        </div>
                     </div>
                  </div>
                  <div class="testimonial-item">
                     <div class="testimonial-content">
                        <div class="rating-start-wrap">
                           <div class="rating-start">
                              <span style="width: 80%"></span>
                           </div>
                        </div>
                        <p>What impressed us the most was the flexibility of Rhino Travels in customizing our tour according to our preferences. We explored the serene landscapes of Assam, visited cultural landmarks, and enjoyed every moment without any hassles.</p>
                        <div class="author-content">
                           <figure class="testimonial-img">
                              <img src="assets/images/img19.jpg" alt="">
                           </figure>
                           <div class="author-name">
                              <h5>ALISON WHITE</h5>
                              <span>TRAVELLERS</span>
                           </div>
                        </div>
                        <div class="testimonial-icon">
                           <i aria-hidden="true" class="fas fa-quote-left"></i>
                        </div>
                     </div>
                  </div>
                  <div class="testimonial-item">
                     <div class="testimonial-content">
                        <div class="rating-start-wrap">
                           <div class="rating-start">
                              <span style="width: 80%"></span>
                           </div>
                        </div>
                        <p>The team at Rhino Travels truly understands the essence of hospitality. From their courteous drivers to their prompt customer service, we felt well taken care of. We highly recommend Rhino Travels to anyone seeking a seamless and delightful travel experience in Guwahati and beyond. Thank you for making our trip to Assam truly memorable!"</p>
                        <div class="author-content">
                           <figure class="testimonial-img">
                              <img src="assets/images/img20.jpg" alt="">
                           </figure>
                           <div class="author-name">
                              <h5>GEORGE SMITH</h5>
                              <span>TRAVELLERS</span>
                           </div>
                        </div>
                        <div class="testimonial-icon">
                           <i aria-hidden="true" class="fas fa-quote-left"></i>
                        </div>
                     </div>
                  </div>
                  <div class="testimonial-item">
                     <div class="testimonial-content">
                        <div class="rating-start-wrap">
                           <div class="rating-start">
                              <span style="width: 80%"></span>
                           </div>
                        </div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                           labore et dolore magna aliqua.</p>
                        <div class="author-content">
                           <figure class="testimonial-img">
                              <img src="assets/images/img19.jpg" alt="">
                           </figure>
                           <div class="author-name">
                              <h5>ALISON WHITE</h5>
                              <span>TRAVELLERS</span>
                           </div>
                        </div>
                        <div class="testimonial-icon">
                           <i aria-hidden="true" class="fas fa-quote-left"></i>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- ***Home testimonial html end here*** -->

      </main>
      <!-- ***site footer html start form here*** -->
      <?php include 'footer.php';?>
      <!-- ***site footer html end*** -->
      <a id="backTotop" href="#" class="to-top-icon">
         <i class="fas fa-chevron-up"></i>
      </a>
      <!-- ***custom search field html*** -->
      
      <!-- ***custom search field html*** -->

   </div>

   <!-- JavaScript -->
   <script src="assets/vendors/jquery/jquery.js"></script>
   <script src="assets/vendors/waypoint/waypoints.js"></script>
   <script src="assets/vendors/bootstrap/js/bootstrap.min.js"></script>
   <script src="assets/vendors/jquery-ui/jquery-ui.min.js"></script>
   <script src="assets/vendors/countdown-date-loop-counter/loopcounter.js"></script>
   <script src="assets/vendors/counterup/jquery.counterup.min.js"></script>
   <script src="../../../unpkg.com/imagesloaded%404.1.4/imagesloaded.pkgd.min.js"></script>
   <script src="assets/vendors/masonry/masonry.pkgd.min.js"></script>
   <script src="assets/vendors/slick/slick.min.js"></script>
   <script src="assets/vendors/fancybox/dist/jquery.fancybox.min.js"></script>
   <script src="assets/vendors/slick-nav/jquery.slicknav.js"></script>
   <script src="assets/js/custom.min.js"></script>
</body>

<!-- Mirrored from demo.stairthemes.com/html/traveler/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 07 Dec 2023 06:59:51 GMT -->

</html>